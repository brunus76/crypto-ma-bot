# Crypto MA Bot

Self-hosted MA crossover bot with BigQuery logging and full backtesting.
